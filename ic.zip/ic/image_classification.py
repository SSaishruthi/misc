import json
import os
# keras layers
from keras.layers import Dense, GlobalAveragePooling2D
# keras applications
from keras.applications import ResNet50
from keras.applications.mobilenet import preprocess_input
# keras preprocessing
from keras.preprocessing.image import ImageDataGenerator
# keras optimizers
from keras.optimizers import Adam  # noqa
# keras functions
from keras.models import Model
from keras.backend import clear_session
#
from keras.callbacks import TensorBoard
import tensorflow as tf
from keras import backend as K
from emetrics import EMetrics
from os import environ
import keras
import json
import os.path
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import RMSprop
import os
from os import environ
from keras.callbacks import TensorBoard
from emetrics import EMetrics



with open('ic/param.json') as config_file:
    param_data = json.load(config_file)

data_dir = os.path.join(os.environ['DATA_DIR'], 'data')
#result_dir = os.environ['RESULT_DIR']

# writing the train model and getting input data
if environ.get('RESULT_DIR') is not None:
    result_dir = os.path.join(os.environ["RESULT_DIR"], "model")
else:
    result_dir = "model"

os.makedirs(result_dir, exist_ok=True)

#writing metrics
if environ.get('JOB_STATE_DIR') is not None:
    tb_directory = os.path.join(os.environ["JOB_STATE_DIR"], "logs", "tb", "test")
else:
    tb_directory = os.path.join("logs", "tb", "test")

os.makedirs(tb_directory, exist_ok=True)
tensorboard = TensorBoard(log_dir=tb_directory)

###############################################################################
# Set up HPO.
###############################################################################

config_file = "config.json"

if os.path.exists(config_file):
    with open(config_file, 'r') as f:
        json_obj = json.load(f)
    hpo_epoch = json_obj["epoch"]
else:
    hpo_epoch = 2

def getCurrentSubID():
    if "SUBID" in os.environ:
        return os.environ["SUBID"]
    else:
        return None

class HPOMetrics(keras.callbacks.Callback):
    def __init__(self):
        self.emetrics = EMetrics.open(getCurrentSubID())
    
    def on_epoch_end(self, epoch, logs={}):
        train_results = {}
        test_results = {}
        
        for key, value in logs.items():
            if 'val_' in key:
                test_results.update({key: value})
            else:
                train_results.update({key: value})
        
        print('EPOCH ' + str(epoch))
        self.emetrics.record("train", epoch, train_results)
        self.emetrics.record(EMetrics.TEST_GROUP, epoch, train_results)

    def close(self):
        self.emetrics.close()

###############################################################################


def base_model_fn(model_name):
    return model_name(weights='imagenet', include_top=False)


def build_model(base_model, num_classes):
    x = base_model.output
    x = GlobalAveragePooling2D(name='Avg_pool_1')(x)
    x = Dense(1024, activation='relu', name='dense_one')(x)
    x = Dense(1024, activation='relu', name='dense_two')(x)
    x = Dense(512, activation='relu', name='dense_three')(x)
    x = Dense(num_classes, activation='softmax', name='main_output')(x)
    return x


train_datagen = ImageDataGenerator(preprocessing_function=preprocess_input)
#
train_generator = train_datagen.flow_from_directory(data_dir,
                                                    target_size=(224, 224),
                                                    color_mode='rgb',
                                                    batch_size=param_data['batch_size'],
                                                    class_mode=param_data['class_mode'],
                                                    shuffle=True)

label_map = [[v, k] for k, v in train_generator.class_indices.items()]
label_dict = {}
for i in range(len(label_map)):
    label_dict[i] = label_map[i]

with open(os.path.join(result_dir, 'class_index.json'), 'w') as f:
    json.dump(label_dict, f)

num_classes = len(label_dict.keys())

clear_session()
base_model = base_model_fn(ResNet50)
final_model = build_model(base_model, num_classes)

model = Model(inputs=base_model.input, outputs=final_model)

for layer in base_model.layers:
    layer.trainable = False

# compile model
model.compile(optimizer=param_data['optimizer'],
              loss=param_data['loss'],
              metrics=list(param_data['metrics'].values()))
# calculate step size
step_size_train = train_generator.n // train_generator.batch_size
#
hpo = HPOMetrics()
#
model.fit_generator(generator=train_generator,
                    steps_per_epoch=step_size_train,
                    epochs=hpo_epoch,
                    callbacks=[tensorboard, hpo])

hpo.close()

model.save(os.path.join(result_dir, 'resnet50.h5'))

builder = tf.saved_model.builder.SavedModelBuilder(os.path.join(result_dir, 'tf'))

signature = tf.saved_model.signature_def_utils.predict_signature_def(inputs={'input': model.inputs[0]},
                                                                     outputs={'output': model.outputs[0]})

with K.get_session() as sess:
    builder.add_meta_graph_and_variables(
        sess=sess,
        tags=[tf.saved_model.tag_constants.SERVING],
        signature_def_map={
            tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY: signature}
    )
    builder.save()
